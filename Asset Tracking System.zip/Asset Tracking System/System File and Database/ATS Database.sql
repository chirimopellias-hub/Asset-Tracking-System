-- Create the database
CREATE DATABASE IF NOT EXISTS jsc_asset_tracking_system;
USE jsc_asset_tracking_system;

-- Employee table
CREATE TABLE Employee (
    empID VARCHAR(100) PRIMARY KEY,
    empName VARCHAR(100),
    empSurname VARCHAR(100),
    empDepartment VARCHAR(100),
    empDesignation VARCHAR(100),
    empStation VARCHAR(100),
    empAddress VARCHAR(100),
    empPhone VARCHAR(100),
    empEmail VARCHAR(100)  
);

-- Users table
CREATE TABLE Users (
    userID VARCHAR(100) PRIMARY KEY,
    empID VARCHAR(100),
    userName VARCHAR(100),
    userPassword VARCHAR(100),  
    userStation VARCHAR(100),
    adminPermission BOOLEAN DEFAULT FALSE,  
    viewOnly BOOLEAN DEFAULT TRUE,    
   assetsPermssion BOOLEAN DEFAULT FALSE,   
    FOREIGN KEY (empID) REFERENCES Employee(empID) 
);



-- Invoices table
CREATE TABLE Invoices (
    invoiceNumber VARCHAR(100) PRIMARY KEY,
    supplierID VARCHAR(100),
    quantity INT,
    unitPrice Decimal(10,2),
    totalCost Decimal(10,2),
    taxAmount Decimal(10,2),
    grandTotal Decimal(10,2),
    recievedBy VARCHAR(100),
    procurementMethod VARCHAR(100),
    paymentMethod VARCHAR(100),
    paymentStatus VARCHAR(100),
    receivingDate VARCHAR(100)  
);
-- Assets table
CREATE TABLE Assets (
    asstID VARCHAR(100) PRIMARY KEY,
    invoiceNumber VARCHAR(100),
    asstCategory VARCHAR(100),
    asstSubCategory VARCHAR(100),
    asstSerialNumber VARCHAR(100),
    asstBrand VARCHAR(100),
    asstModelNumber VARCHAR(100),
    warrantStart VARCHAR(100),
    warrantEnd VARCHAR(100),
    asstCondtion VARCHAR(100),
    asstStatus VARCHAR(100),
    FOREIGN KEY (invoiceNumber) REFERENCES Invoices(invoiceNumber) 
);


-- AssetAssign table
CREATE TABLE AssetAssign (
    asstID VARCHAR(100) PRIMARY KEY,
    custodianID VARCHAR(100),
    assignerID VARCHAR(100),
    assignedDepartment VARCHAR(100),
    asstCondition VARCHAR(100),
    assignPuprose VARCHAR(100),
    FOREIGN KEY (custodianID) REFERENCES Employee(empID),
    FOREIGN KEY (asstID) REFERENCES Assets(asstID) 
);

-- AssetReturn table
CREATE TABLE AssetReturn (
    returnID INT PRIMARY KEY AUTO_INCREMENT,
    asstID VARCHAR(100),
    custodianID VARCHAR(100),
    returnedBy VARCHAR(100),
    receivedBy VARCHAR(100),
    asstCondition VARCHAR(100),
    asstStatus VARCHAR(100),
    returnPuprose VARCHAR(100),
    timeDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (custodianID) REFERENCES Employee(empID),
    FOREIGN KEY (receivedBy) REFERENCES Users(userID)
);


-- AssetHistory table
CREATE TABLE AssetHistory (
    activityID INT PRIMARY KEY AUTO_INCREMENT,
    asstID VARCHAR(100),
    userID VARCHAR(100),
    timeDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    activity text,
    FOREIGN KEY (userID) REFERENCES Users(userID)
);

-- Court table
CREATE TABLE Court (
    station_id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(100),
    type VARCHAR(100),
    address TEXT,
    contact VARCHAR(50),
    email VARCHAR(100),
    head VARCHAR(100)
);

-- Department table
CREATE TABLE Department (
    department_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100)
);






-- Designation table
CREATE TABLE Designation (
    designation_id INT PRIMARY KEY AUTO_INCREMENT,
    department_id INT,
    designation_name VARCHAR(100),
    FOREIGN KEY (department_id) REFERENCES Department(department_id) 
);

-- System Logs table
CREATE TABLE SystemLogs (
    activityID INT PRIMARY KEY AUTO_INCREMENT,
    userID VARCHAR(100),
    timeDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    activity text
);
employee